package com.example.demo.entity;

public enum EmpRole {

	DIRECTOR,
	MANAGER,
	EMPLOYEE

}
